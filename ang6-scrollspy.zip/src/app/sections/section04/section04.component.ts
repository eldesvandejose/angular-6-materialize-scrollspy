import { Component, OnInit } from '@angular/core';

declare var $: any;

@Component({
  selector: 'a6ss-section04',
  templateUrl: './section04.component.html',
  styleUrls: ['./section04.component.css']
})
export class Section04Component implements OnInit {

  constructor() { }

  ngOnInit() { }
}
