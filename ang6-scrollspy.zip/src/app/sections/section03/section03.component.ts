import { Component, OnInit } from '@angular/core';

declare var $: any;

@Component({
  selector: 'a6ss-section03',
  templateUrl: './section03.component.html',
  styleUrls: ['./section03.component.css']
})
export class Section03Component implements OnInit {

  constructor() { }

  ngOnInit() { }
}
