import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Section01Component } from './section01/section01.component';
import { Section02Component } from './section02/section02.component';
import { Section03Component } from './section03/section03.component';
import { Section04Component } from './section04/section04.component';
import { Section05Component } from './section05/section05.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    Section01Component,
    Section02Component,
    Section03Component,
    Section04Component,
    Section05Component
  ],
  exports: [
    Section01Component,
    Section02Component,
    Section03Component,
    Section04Component,
    Section05Component
  ]
})
export class SectionsModule {}
