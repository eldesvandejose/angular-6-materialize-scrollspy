import { Component } from '@angular/core';

declare var $: any;

@Component({
  selector: 'a6ss-section05',
  templateUrl: './section05.component.html',
  styleUrls: ['./section05.component.css']
})
export class Section05Component {

  constructor() { }
}
