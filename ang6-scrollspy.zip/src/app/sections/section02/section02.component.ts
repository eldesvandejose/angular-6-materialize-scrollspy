import { Component } from '@angular/core';

declare var $: any;

@Component({
  selector: 'a6ss-section02',
  templateUrl: './section02.component.html',
  styleUrls: ['./section02.component.css']
})
export class Section02Component {

  constructor() { }
}
