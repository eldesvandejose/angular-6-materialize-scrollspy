import { Component } from '@angular/core';

declare var $: any;

@Component({
  selector: 'a6ss-section01',
  templateUrl: './section01.component.html',
  styleUrls: ['./section01.component.css']
})
export class Section01Component {

  constructor() { }
}
